# import requests
#
# #post请求在这请求谢谢
# r = requests.post("http://127.0.0.1:5000/user/login", data={'username': 'mk3', 'pwd': '2'})
# print(r.status_code)
# print(r.text)