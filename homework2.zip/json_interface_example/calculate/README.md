## user
"name": username, 
"money": 200,
"pocket": {"工具": ["衠钢槊"], "配饰": ["烂银甲"]},//满10 //五个束发紫金冠可换取枭雄金印 获得游戏胜利
'lucky':0,
'wear':{"工具": [], "配饰": []}}#满1 满2 
'onmarket':{"工具": [], "配饰": []}
## market
"goods": username, 
"price": 200,
"sell": "衠钢槊",//满10

//'lucky':0,
//'wear':{"工具": [], "配饰": []}}#满1 满2 
## treasure
"name": '枭雄金印', 
"property": "配饰", 
"value": MAXINT, 
"level": '终极'
## info
用户名密码