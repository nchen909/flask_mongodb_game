#!/usr/bin/env python3
# import pytest
# from flask import Flask
# from flask.testing import FlaskClient
#
# # from calculate.cal import bp
# # from python_flask.action.opt import bp
# from homework2.json_interface_example.calculate.cal import bp
# import os
#
# #@pytest.fixture
# def client():
#     app: Flask = Flask(__name__)
#     app.config['SECRET_KEY'] = os.urandom(24)
#     app.register_blueprint(bp)
#     client= app.test_client(use_cookies=True)
#     return client
