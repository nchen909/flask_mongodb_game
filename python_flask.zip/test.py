import random
import simplejson

# print(random.randint(1,2)) # 左闭右闭
import simplejson as simplejson

str = "{'name' : 'jim', 'sex' : 'male', 'age': 18}"
json = eval(str)
print(type(json))